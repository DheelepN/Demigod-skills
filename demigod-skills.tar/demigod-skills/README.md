# @demigod/skills

> Claude skill suite by Vivid (Dheelep N)

A collection of production-grade Claude skills for book writing, humanizing AI text, upgrading skill files, and the full book production pipeline — installable in one command.

---

## Install

```bash
# Install a single skill
npx @demigod/skills install book-writer

# Install everything at once
npx @demigod/skills install all
```

Skills are copied to `~/.claude/skills/` — Claude picks them up automatically on next session start.

---

## Commands

```bash
npx @demigod/skills install <skill>   # Install one skill
npx @demigod/skills install all       # Install all skills
npx @demigod/skills remove <skill>    # Remove a skill
npx @demigod/skills remove all        # Remove all demigod skills
npx @demigod/skills list              # List available skills + install status
npx @demigod/skills status            # Show which skills are installed
npx @demigod/skills info <skill>      # Show details about a skill
npx @demigod/skills version           # Show package version
```

---

## Skills

### `book-writer`
Full end-to-end book authoring pipeline. Takes a concept document from seed idea to KDP-ready DOCX. Includes concept expansion, structure options, 26-question intake, research bank, table of contents, chapter writing (guided or autonomous), 7-dimension chapter audit, humanizer pass, continuity tracking, and KDP-formatted output.

```bash
npx @demigod/skills install book-writer
```

### `humanizer`
Strips all 25 documented AI writing patterns AND actively rewrites toward Vivid's style DNA simultaneously. Includes a DNA protection layer that identifies and exempts authentic signature constructions before the pattern elimination pass runs. Produces: draft → self-audit → final version → changes summary.

```bash
npx @demigod/skills install humanizer
```

### `overhaul`
Upgrades any skill file from its current version to a dramatically better one. Two modes:
- **Automated** — diagnoses across 6 dimensions and rebuilds completely, no user input needed
- **Personalized** — user-guided, decides scope/depth at each stage

```bash
npx @demigod/skills install overhaul
```

### `concept-expander`
Turns a rough book seed (a paragraph, title, or bullet points) into a complete concept document the book-writer can consume. Outputs logline, core question, reader profile, emotional arc, thematic clusters, comp titles, and chapter territories.

```bash
npx @demigod/skills install concept-expander
```

### `chapter-auditor`
Scores chapters across 7 dimensions before the humanizer pass: voice authenticity, pain-to-transformation arc, sentence rhythm, metaphor quality, structural integrity, AI pattern contamination, and reader resonance. Produces a PASS / CONDITIONAL PASS / REVISE verdict.

```bash
npx @demigod/skills install chapter-auditor
```

### `continuity-tracker`
Maintains a running continuity log across all chapters. Tracks established facts, metaphors, insights, tone decisions, and open threads. Fires a continuity brief before each chapter and updates the log after — detects and surfaces conflicts before they compound.

```bash
npx @demigod/skills install continuity-tracker
```

### `research-aggregator`
Builds a Research Bank organized by chapter — philosophical anchors, quotes, empirical findings, and conceptual oppositions. Tuned specifically for Vivid's genres: philosophy/essay, self-help/motivational, non-fiction/technical.

```bash
npx @demigod/skills install research-aggregator
```

---

## Requirements

- Node.js 16+
- Claude.ai (any paid plan) or Claude Code

Skills install to `~/.claude/skills/` and are picked up automatically by Claude on session start.

---

## Author

**Dheelep N (Vivid)** — developer, author, security researcher  
8 published books · 6 research papers · 9+ production tools

---

## License

MIT
